(function() {
  document.getElementById('images_subjects').innerHTML = "herein herefda ";
  /*
  '{% for l in all_lessons %}' +
  '{% if l.is_public %}' +
  '<div class="column is-one-fifth">' +
    '<div class="box alt-front-background">' +
      '<a href="{% url '"lesson:show_lesson"' l.id %}">' +
        '<div class="container-img">' +
          '<figure class="image is-1by1">' +
            '<img src="{{ l.img.url }}" class="is-rounded" style="object-fit: cover;" alt="Image not found" onerror="this.onerror=null;this.src='"{% static 'teach/images/no_image_available.PNG' %}"';">' +
          '</figure>' +
          '<img class="icon" src="{{ l.icon }}">' +
        '</div>' +
      '</a>' +
      '<small style="color:white;">' +
        'Created: {{ l.created }}' +
      '</small>' +
    '</div>' +
  '</div>' +
  '{% endif %}' +
  '{% endfor %}';
  */
}());
