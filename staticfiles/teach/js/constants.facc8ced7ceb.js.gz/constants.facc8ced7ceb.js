// Used in base.html for top left subject icon

const MATH_ICON = 'https://img.icons8.com/dusk/64/000000/math.png'
const SCIENCE_ICON = 'https://img.icons8.com/dusk/64/000000/bunsen-burner.png'
const ENGLISH_ICON = 'https://img.icons8.com/dusk/64/000000/class.png'
const HISTORY_ICON = 'https://img.icons8.com/dusk/64/000000/archeology.png'
const SUBJECT_ICON = 'https://img.icons8.com/dusk/50/000000/book-and-pencil.png'
